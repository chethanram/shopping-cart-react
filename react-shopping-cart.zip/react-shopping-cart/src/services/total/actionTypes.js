export const UPDATE_CART = 'UPDATE_CART';
